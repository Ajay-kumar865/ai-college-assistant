from pymongo import MongoClient
from datetime import datetime
import os

MONGO_URI = os.getenv("MONGO_LOG_URI")

client = MongoClient(MONGO_URI)
db = client["ai_assistant_logs"]

query_logs = db["queries"]
response_logs = db["responses"]
error_logs = db["errors"]


def log_query(data: dict):
    data["timestamp"] = datetime.utcnow()
    query_logs.insert_one(data)


def log_response(data: dict):
    data["timestamp"] = datetime.utcnow()
    response_logs.insert_one(data)


def log_error(data: dict):
    data["timestamp"] = datetime.utcnow()
    error_logs.insert_one(data)
