import logging
from pathlib import Path
from logging.handlers import RotatingFileHandler


class Log_Setup:
    def setup_logging(self):
        log_dir = Path("logs")
        log_dir.mkdir(exist_ok=True)

        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
        )

        handlers = {
            "queries": RotatingFileHandler(
                log_dir / "queries.log",
                maxBytes=5_000_000,
                backupCount=5,
                encoding="utf-8",
            ),
            "responses": RotatingFileHandler(
                log_dir / "responses.log",
                maxBytes=5_000_000,
                backupCount=5,
                encoding="utf-8",
            ),
            "feedback": RotatingFileHandler(
                log_dir / "feedback.log",
                maxBytes=2_000_000,
                backupCount=3,
                encoding="utf-8",
            ),
        }

        for handler in handlers.values():
            handler.setFormatter(formatter)

        logging.getLogger("queries").handlers = [handlers["queries"]]
        logging.getLogger("responses").handlers = [handlers["responses"]]
        logging.getLogger("feedback").handlers = [handlers["feedback"]]

        logging.getLogger("queries").setLevel(logging.INFO)
        logging.getLogger("responses").setLevel(logging.INFO)
        logging.getLogger("feedback").setLevel(logging.INFO)

        # feedback

        logs_dir = Path(__file__).parent

        logging.basicConfig(level=logging.INFO)

        self.feedback_logger = logging.getLogger("feedback")
        self.feedback_logger.setLevel(logging.INFO)

        fh = logging.FileHandler(logs_dir / "feedback.log")
        fh.setFormatter(logging.Formatter("%(message)s"))

        self.feedback_logger.addHandler(fh)
