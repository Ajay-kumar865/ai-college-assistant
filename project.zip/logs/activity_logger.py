import json
from datetime import datetime
from pathlib import Path

LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)

ACTIVITY_LOG = LOG_DIR / "admin_activity.log"


def log_activity(
    actor: str,
    role: str,
    action: str,
    target: str | None = None,
    meta: dict | None = None,
):
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "actor": actor,
        "role": role,
        "action": action,
        "target": target,
        "meta": meta or {},
    }

    with open(ACTIVITY_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")
