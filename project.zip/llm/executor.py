from .key_pool_executor import KeyPoolExecutor
import logging

logger = logging.getLogger("responses")

from app.config import GROQ_API_KEYS, GEMINI_API_KEYS
from llm.providers.groq import GroqProvider
from llm.providers.gemini import GeminiProvider
from app.config import GOOSE_API_KEYS
from llm.providers.Goose import GooseProvider


class LLMExecutor:
    def __init__(self):
        self.key_pools = {
            "groq": KeyPoolExecutor(GroqProvider, GROQ_API_KEYS),
            "gemini": KeyPoolExecutor(GeminiProvider, GEMINI_API_KEYS),
            "goose": KeyPoolExecutor(GooseProvider, GOOSE_API_KEYS),
        }

    def execute(self, provider_name: str, provider, prompt: str, context=None):
        if provider_name in self.key_pools:
            result = self.key_pools[provider_name].execute(prompt, context)
        else:
            raise RuntimeError(f"No key pool registered for provider: {provider_name}")

        # ✅ FINAL response logging (single source of truth)
        from logs.db_logger import log_response

        log_response(
            {
                "provider": provider_name,
                "response": str(result),
            }
        )

        return result
